# Zombi Bot v14
# If u have problem in BOT
# Contact me ?
# Email : nedjworgan@gmail.com
# ICQ: @viper1337official
# My Facebook Page: https://www.fb.com/viper1337official/
# Telegram: https://t.me/Viper1337official

Install Python 2.7 To Run All Tools

Module :

-pip3 install -r requirements.txt

[Zombi Bot V14  - Only work for python 2.7]

Module :

-pip install request
-pip install requests
-pip install colorama
-pip install bs4
-pip install tldextract

Thanks you~

